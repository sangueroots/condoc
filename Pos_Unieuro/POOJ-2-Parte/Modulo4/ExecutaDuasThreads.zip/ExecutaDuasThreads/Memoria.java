
import java.util.Random;   
import java.util.concurrent.locks.Lock;   
import java.util.concurrent.locks.ReentrantLock;   
import java.util.concurrent.locks.Condition;   

  
public class Memoria implements Buffer {   
  
// Bloqueio para controlar sincronização com esse buffer   
private Lock bloquearAcesso = new ReentrantLock();   
  
// condições para controlar leitura e gravação   
private Condition canGrava = bloquearAcesso.newCondition();   
private Condition canLer = bloquearAcesso.newCondition();   
private static Random gerador= new Random();   
private int objeto = -1; // compartilhado pelas threads producer e consumer   
private boolean ocupada = false; // se o buffer estiver ocupado   
int i;   
// coloca o valor int no buffer   
  
public void set( int n )
{   
for(i=0;i<=5;i+=1)   
bloquearAcesso.lock(); // bloqueia esse objeto   
  
// envia informações de thread e de buffer para a saída, então espera   
  
try   
{   
// enquanto o buffer não estiver vazio, coloca thread no estado de espera   
while ( ocupada )   
{   
System.out.println( "Thread Tentando Escrever." );   
displayState( "Buffer cheio.Thread Então espera." );   
canGrava.await(); // espera até que o buffer esteja vazio   
} // end while   
  
objeto = n; // configura novo valor de buffer   
  
// indica que a produtora não pode armazenar outro valor   
// até a consumidora recuperar valor atual de buffer   
ocupada = true;   
  
displayState( "Thread escreve " + objeto );   
  
// sinaliza a thread que está esperando para ler a partir do buffer   
canLer.signal();   
} // fim do try   
catch ( InterruptedException exception )   
{   
exception.printStackTrace();   
} // fim do catch   
finally   
{   
bloquearAcesso.unlock(); // desbloqueia esse objeto   
} // fim do finally   
} // fim do método set   
  
// retorna valor do buffer   
public int get()   
{   
int readValue = 0; // inicializa de valor lido a partir do buffer   
bloquearAcesso.lock(); // bloqueia esse objeto   
// envia informações de thread e de buffer para a saída, então espera   
try   
{   
// enquanto os dados não são lidos, coloca thread em estado de espera   
while ( !ocupada )   
{   
System.out.println( "Thread Tenta ler." );   
displayState( "Buffer vazio.Thread Espera." );   
canLer.await(); // espera até o buffer tornar-se cheio   
} // fim do while   
  
// indica que a produtora pode armazenar outro valor   
// porque a consumidora acabou de recuperar o valor do buffer   
ocupada = false;   
  
readValue = objeto; // recupera o valor do buffer   
displayState( "Thread lê " + readValue );   
// sinaliza a thread que está esperando o buffer tornar-se vazio   
Thread.sleep( gerador.nextInt( 2000 ) ); // thread sleep   
canGrava.signal();   
} // fim do try   
// se a thread na espera tiver sido interrompida, imprime o rastreamento de pilha   
catch ( InterruptedException exception )   
{   
exception.printStackTrace();   
} // fim do catch   
finally   
{   
bloquearAcesso.unlock(); // desbloqueia esse objeto   
} // fim do finally   
  
return readValue;   
} // fim do método get   
  
// exibe a operação atual e o estado de buffer   
public void displayState( String operation )   
{   
System.out.printf( "%-40s%d\t\t%b\n\n", operation, objeto,   
ocupada );   
} // fim do método displayState   
} // fim da classe SynchronizedBuffer   
 
  
 
 
class rand {   
  
Random rand = new Random();   
int n = rand.nextInt(30) + 10;   
}   