
/* Aplicativo mostra duas threads que manipulam um buffer sincronizado.
   Criado por Murilo Silva Andrade Souza 24/07/2013
   
   
   
   */

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutaThreads
{
public static void main( String[] args )
{
// cria novo pool de threads com duas threads
ExecutorService application = Executors.newFixedThreadPool( 2 );

// cria ExecutaThreads para armazenar ints
Buffer sharedLocation = new Memoria();
System.out.printf( "%-40s%s\t\t%s\n%-40s%s\n\n", "Operação",
"Memória", "Ocupada", "---------", "------\t\t--------" );

try // tenta iniciar a produtora e a consumidora
{
application.execute( new Producer( sharedLocation ) );
application.execute( new Consumer( sharedLocation ) );
} // fim do try
catch ( Exception exception )
{
exception.printStackTrace();
} // fim do catch

application.shutdown();
} // fim do main
} // fim da classe Executa Threads