/** Path: plugins qtype_multichoice **/
.que.multichoice .answer .specificfeedback {
    padding: 0 0.7em;
    background: #FFF3BF;
}
.que.multichoice .answer .specificfeedback * {
    display: inline;
    background: #FFF3BF;
}
.que.multichoice .answer div.r0,
.que.multichoice .answer div.r1 {
    padding: 0.3em;
}
.que.multichoice .feedback .rightanswer * {
    display: inline;
}
