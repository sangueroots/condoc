/** Path: plugins mod_imscp **/
/*** Modules: IMS CP ***/

#page-mod-imscp-view #imscp_nav {
 text-align: center;
 margin-bottom: 5px;
 margin-top: 10px;
}

#page-mod-imscp-view #imscp_toc .ygtv-highlight1 {
  font-weight: bold;
}

#page-mod-imscp-view .yui-layout-hd {
 background-image: none;
 background-color: #DDDDDD;
}

#page-mod-imscp-view .yui-layout-hd h2 {
 color: black;
}