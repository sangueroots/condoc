/** Path: plugins workshopallocation_random **/
.path-mod-workshop .random-allocator .warning {
    width: 80%;
    margin: 0px auto 15px auto;
}
