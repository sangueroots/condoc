/** Path: plugins block_recent_activity **/
.block_recent_activity .activitydate,
.block_recent_activity .activityhead {text-align:center;}
.block_recent_activity .unlist li {margin-bottom:1em;}
.block_recent_activity li .head .date  {float:right;}

.dir-rtl .block_recent_activity .content h3 {text-align: right;}