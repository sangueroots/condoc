/** Path: plugins qtype_match **/
.que.match .feedback .rightanswer * {
    display: inline;
}
