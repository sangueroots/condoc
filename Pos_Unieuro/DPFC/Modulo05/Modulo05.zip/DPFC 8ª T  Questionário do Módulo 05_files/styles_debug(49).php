/** Path: plugins report_loglive **/
#page-report-loglive-index .info {margin:10px;}
