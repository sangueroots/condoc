/** Path: plugins qtype_shortanswer **/
.que.shortanswer .answer {
    padding: 0.3em;
    width: auto;
    display: inline;
}
.que.shortanswer .answer input {
    width: 80%;
}
