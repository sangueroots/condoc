/** Path: plugins block_course_list **/
.block_course_list .footer {margin-top: 5px;}