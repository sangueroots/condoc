/** Path: plugins block_search_forums **/
.block_search_forums .searchform {text-align: center;}
.block_search_forums .searchform img {vertical-align: middle;}
.block_search_forums .searchform img.resize {width: 1em;height: 1.1em;}
.block_search_forums .invisiblefieldset {display: block;}