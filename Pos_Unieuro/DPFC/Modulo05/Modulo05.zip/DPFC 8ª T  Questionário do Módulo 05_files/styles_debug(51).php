/** Path: plugins report_participation **/
#page-report-participation-index .participationselectform {margin:10px auto;}
#page-report-participation-index .participationselectform label {margin-left:15px;margin-right:5px;}
