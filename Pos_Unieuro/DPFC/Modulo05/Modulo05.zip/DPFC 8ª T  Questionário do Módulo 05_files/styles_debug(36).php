/** Path: plugins block_online_users **/
.block_online_users .content .list li.listentry {clear:both;}
.block_online_users .content .list li.listentry .user {float:left;position:relative;}
.block_online_users .content .list li.listentry .message {float:right;}
.block_online_users .content .info {text-align:center;}

.dir-rtl .block_online_users .content .list li.listentry .user {float:right;}
.dir-rtl .block_online_users .content .list li.listentry .message {float:left;}