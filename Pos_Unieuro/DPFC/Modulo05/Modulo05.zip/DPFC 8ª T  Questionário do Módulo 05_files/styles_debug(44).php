/** Path: plugins filter_glossary **/
#glossaryfilteroverlayprogress {position:fixed;top:50%;width:100%;text-align:center;}
