/** Path: plugins qtype_truefalse **/
.que.truefalse .answer div.r0,
.que.truefalse .answer div.r1 {
    padding: 0.3em;
}
