/** Path: plugins quiz_grading **/
#page-mod-quiz-report #manualgradingform {width: 100%;}
#page-mod-quiz-report #manualgradingform.mform br {clear: none;}
#page-mod-quiz-report #manualgradingform.mform .clearfix:after {clear: none;}
#page-mod-quiz-report #manualgradingform .que {margin-bottom: 0.7em;}
