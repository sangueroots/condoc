/** Path: plugins qtype_calculatedsimple **/
.que.calculatedsimple .answer {
    padding: 0.3em;
    width: auto;
    display: inline;
}
.que.calculatedsimple .answer input[type="text"] {
    width: 30%;
}
