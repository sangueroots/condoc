/** Path: parents canvas popups **/
body.pagelayout-popup {
    background: #fff !important;
}