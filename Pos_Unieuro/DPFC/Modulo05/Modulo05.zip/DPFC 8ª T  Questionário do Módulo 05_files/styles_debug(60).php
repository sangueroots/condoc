/** Path: plugins tool_langimport **/

#page-admin-tool-langimport-index .generalbox table {margin:auto;width:100%;}

#page-admin-tool-langimport-index .generalbox,
#page-admin-tool-langimport-index .generalbox table {text-align: center;}
