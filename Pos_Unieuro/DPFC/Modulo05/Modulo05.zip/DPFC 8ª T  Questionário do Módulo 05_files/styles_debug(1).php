/** Path: plugins qtype_calculatedmulti **/
.que.calculatedmulti .answer .specificfeedback {
    display: inline;
    padding: 0 0.7em;
    background: #FFF3BF;
}
.que.calculatedmulti .answer .specificfeedback * {
    display: inline;
    background: #FFF3BF;
}
.que.calculatedmulti .answer div.r0,
.que.calculatedmulti .answer div.r1 {
    padding: 0.3em;
}
