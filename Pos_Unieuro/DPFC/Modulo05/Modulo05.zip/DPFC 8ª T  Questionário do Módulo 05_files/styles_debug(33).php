/** Path: plugins block_messages **/
.block_messages .content {text-align:left;padding-top:5px;}
.block_messages .content .list li.listentry {clear:both;}
.block_messages .content .list li.listentry .user {float:left;position:relative;}
.block_messages .content .list li.listentry .message {float:right;}
.block_messages .content .info {text-align:center;}
.block_messages .content .footer {clear:both;}

.dir-rtl .block_messages .content .list li.listentry .user {float:right;}
.dir-rtl .block_messages .content .list li.listentry .message {float:left;}