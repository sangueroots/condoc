/** Path: plugins qtype_calculated **/
.que.calculated .answer {
    padding: 0.3em;
    width: auto;
    display: inline;
}
.que.calculated .answer input[type="text"] {
    width: 30%;
}
