/** Path: plugins block_tag_flickr **/
.block_tag_flickr .flickr-photos {padding:3px;}