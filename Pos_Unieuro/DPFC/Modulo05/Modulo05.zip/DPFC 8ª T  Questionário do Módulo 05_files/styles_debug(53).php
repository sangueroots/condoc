/** Path: plugins report_stats **/
#page-report-stats-index .graph {margin-bottom: 1em;}
