/** Path: plugins block_html **/
.block.block_html .content {padding:0;}
.block.block_html .content .no-overflow {padding:4px;}