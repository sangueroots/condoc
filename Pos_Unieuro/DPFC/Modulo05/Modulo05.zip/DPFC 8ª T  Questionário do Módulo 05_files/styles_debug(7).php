/** Path: plugins qtype_numerical **/
.que.numerical .answer {
    padding: 0.3em;
    width: auto;
    display: inline;
}
.que.numerical .answer input[type="text"] {
    width: 30%;
}
