/** Path: parents canvas tables **/
.editcourse th,
.editcourse td,
.generaltable th,
.generaltable td,
#page-admin-course-category .generalbox th,
#page-admin-course-category .generalbox td,
#attempts th,
#attempts td,
.environmenttable th,
.environmenttable td,
.forumheaderlist td,
.forumheaderlist th {
    border: 1px solid #ddd;
    border-collapse: collapse;
}

#page-admin-course-category .generalbox th,
.editcourse .header,
.results .header,
#attempts .header,
.generaltable .header,
.environmenttable th,
.forumheaderlist th {
    background: #f3f3f3;
    border-bottom-width: 2px;
}