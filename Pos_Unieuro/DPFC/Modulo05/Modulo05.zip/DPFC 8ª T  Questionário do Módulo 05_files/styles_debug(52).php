/** Path: plugins report_progress **/
#page-report-progress-index th,
#page-report-progress-index td {padding:2px 4px;font-weight:normal;border-right: 1px solid #EEE;}
#page-report-progress-index .progress-actions {text-align:center;}
#page-report-progress-index .completion_pagingbar {margin:1em 0;text-align:center;}
#page-report-progress-index .completion_prev {display:inline;margin-right:2em;}
#page-report-progress-index .completion_pagingbar p {display:inline;margin:0;}
#page-report-progress-index .completion_next {display:inline;margin-left:2em;}
