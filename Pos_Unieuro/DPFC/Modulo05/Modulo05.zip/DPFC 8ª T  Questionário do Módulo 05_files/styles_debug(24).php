/** Path: plugins mod_url **/
.path-mod-url .resourcecontent {text-align: center;}
