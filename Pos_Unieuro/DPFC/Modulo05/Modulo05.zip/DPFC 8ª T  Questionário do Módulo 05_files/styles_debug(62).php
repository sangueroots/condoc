/** Path: plugins tool_qeupgradehelper **/
#page-admin-tool-qeupgradehelper-index .dimmed {
    color: grey;
}
#page-admin-tool-qeupgradehelper-index .dimmed a {
    color: #88c;
}
