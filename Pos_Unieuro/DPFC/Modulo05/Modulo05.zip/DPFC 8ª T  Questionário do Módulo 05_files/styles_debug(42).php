/** Path: plugins block_tag_youtube **/
.block_tag_youtube .youtube-thumb {padding: 3px;padding-bottom: 0.5em;display: block;float: left;}
.block_tag_youtube .yt-video-entry li {clear: left;}