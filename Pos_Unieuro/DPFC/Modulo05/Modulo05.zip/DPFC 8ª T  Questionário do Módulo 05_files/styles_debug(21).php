/** Path: plugins mod_resource **/
.path-mod-resource .resourcecontent {text-align: center;}
