/** Path: plugins block_myprofile **/
.block_myprofile img.profilepicture { height:100px; width:100px;}
.block_myprofile .myprofileitem.fullname {font-size:1.5em; font-weight: bold;}
.block_myprofile .myprofileitem.edit {text-align: right;}

