/** Path: plugins report_log **/
#page-report-log-index .info {margin:10px;}
#page-report-log-index .logselectform {margin:10px auto;}

#page-report-log-user .info {margin:10px; text-align:center;}
#page-report-log-user .graph {text-align: center;}
